===============
librgw (Python)
===============

.. highlight:: python

The `rgw` python module provides file-like access to rgw.

API Reference
=============

.. automodule:: rgw
    :members: LibRGWFS, FileHandle

