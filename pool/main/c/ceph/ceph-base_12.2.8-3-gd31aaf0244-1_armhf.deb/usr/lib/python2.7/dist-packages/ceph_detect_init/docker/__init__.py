def choose_init():
    """Returns 'none' because we are running in a container"""
    return 'none'
